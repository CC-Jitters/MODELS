package com.streamliners.models;

public class Product {
    public String name, imageURL;
    public Product(String name, String imageURL) {
        this.name = name;
        this.imageURL = imageURL;
    }

    /*public Product() {
        name = "A";
        imageURL = "aaa";
    }*/

    @Override
    public String toString() {
        return "Product{" +
                "name='" + name + '\'' +
                ", imageURL='" + imageURL + '\'' +
                '}';
    }
}
