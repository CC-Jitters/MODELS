package com.streamliners;

import com.streamliners.models.Product;
import com.streamliners.models.Variant;
import com.streamliners.models.VariantsBasedProduct;
import com.streamliners.models.WeightBasedProduct;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        /*Product product = new Product("Apple", "abc");
        System.out.println(product);
        Product product1 = new Product();
        System.out.println(product1.name);*/
        /*WeightBasedProduct product = new WeightBasedProduct("Apple", "", 1, 100);
        System.out.println(product);*/
        /*List<String> strings = new ArrayList<>(
                Arrays.asList("A", "B", "C")
        );
        //strings.remove("D");
        if(strings.contains("D")) {
            System.out.println("Exist!");
        }
        else {
            System.out.println("Not Exist!");
        }
        System.out.println(strings);*/
        /*List<Product> products = new ArrayList<>(
                Arrays.asList(new Product("A", ""),
                              new Product("B", ""),
                              new Product("C", ""))
        );
        System.out.println(products);*/
        List<Variant> variants = new ArrayList<>(
                Arrays.asList(new Variant("500g", 90),
                              new Variant("1kg", 180))
        );
        List<Variant> variants1 = new ArrayList<>(
                Arrays.asList(new Variant("500g", 50),
                              new Variant("1kg", 100))
        );
        VariantsBasedProduct product = new VariantsBasedProduct(
                "Apple", "", variants);
        VariantsBasedProduct product1 = new VariantsBasedProduct(
                "Banana", "", variants1);
        System.out.println(product);
        System.out.println(product1);
    }
}
